sub Main()
    reg = CreateObject("roRegistrySection", "profile")
    if reg.Exists("primaryfeed")
        url = reg.Read("primaryfeed")
        if url = "" or url = invalid
            url = "https://raw.githubusercontent.com/tinogamboa/Listas/refs/heads/main/1.m3u"
        end if
    else
        url = "https://raw.githubusercontent.com/tinogamboa/Listas/refs/heads/main/1.m3u"
    end if

    screen = CreateObject("roSGScreen")
    port = CreateObject("roMessagePort")
    screen.SetMessagePort(port)

    scene = screen.CreateScene("HomeScene")
    ' Le pasamos la URL al HomeScene pro
    scene.feedurl = url

    screen.Show()

    while true
        msg = wait(0, port)
        if type(msg) = "roSGScreenEvent"
            if msg.isScreenClosed() then
                return
            end if
        end if
    end while
end sub